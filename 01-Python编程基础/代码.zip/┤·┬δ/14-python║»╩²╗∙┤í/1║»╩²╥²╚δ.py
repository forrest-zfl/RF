# 需求: 当前文件中,有10个地方需要输出1-100之间所有的数字
'''
num = 1
while num <= 100:
    print(num)
    num += 1

num = 1
while num <= 100:
    print(num)
    num += 1

num = 1
while num <= 100:
    print(num)
    num += 1


num = 1
while num <= 100:
    print(num)
    num += 1
'''
# 函数的方式进行处理:
# 函数定义:
def demo():
    num = 1
    while num <= 100:
        print(num)
        num += 1
# 函数调用
demo()
demo()
demo()