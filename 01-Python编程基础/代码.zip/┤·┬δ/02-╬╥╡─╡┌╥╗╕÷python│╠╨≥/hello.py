print("hello,world")
print("goodbye,world")