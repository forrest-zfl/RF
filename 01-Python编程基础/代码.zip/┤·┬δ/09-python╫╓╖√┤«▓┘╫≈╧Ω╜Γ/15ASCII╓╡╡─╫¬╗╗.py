# chr()  表示将对应的ASCII的值转换为字符
# ord() 获取对应字符的ASCII的值

print(chr(87))  # W
print(ord('s'))  # 115
