str1 = 'i Miss You Very Much'

# upper()  将字符串中的小写字母转换为大写字母
print(str1.upper())  # I MISS YOU VERY MUCH

# lower() 将字符串中的大写字母转换为小写字母
print(str1.lower())  # i miss you very much

# swapcase()将字符串中的大写字母转换为小写,将小写字母转换为大写

print(str1.swapcase())  # I mISS yOU vERY mUCH

# title()将字符串中的每个单词的首字母转换为大写
str2 = 'welcome to qian feng'
print(str2.title())  # Welcome To Qian Feng