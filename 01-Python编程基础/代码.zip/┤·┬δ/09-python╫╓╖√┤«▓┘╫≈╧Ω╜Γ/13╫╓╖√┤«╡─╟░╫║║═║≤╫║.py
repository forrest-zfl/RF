# 前缀和后缀是指:判断字符串是否以指定字符开头或者以指定字符结束

# startswith():表示以指定字符开头
str1 = 'HelloPython'
print(str1.startswith('Hello'))  # True

# endswith() :表示以指定字符结束
print(str1.endswith('thon'))   # True