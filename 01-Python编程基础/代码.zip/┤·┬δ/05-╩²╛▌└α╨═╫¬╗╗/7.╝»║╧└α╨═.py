# 集合用{ }标识, { }里面只有值,没有索引.

set1 = {123,87.56,True,False}
print(set1)