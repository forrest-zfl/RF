# 字典用"{ }"标识。
# 字典由索引(key)和它对应的值value组成。{key1:value1,key2:value2.......}

user = {"name":"吴京","age":46,"sex":"男","weight":150}
print(user)