# 死循环
while True:
    print('hello')

# 总结:
'''
1.for循环一般用于已知循环次数的情况
2.while循环一般用于未知循环次数的情况或者死循环
'''
