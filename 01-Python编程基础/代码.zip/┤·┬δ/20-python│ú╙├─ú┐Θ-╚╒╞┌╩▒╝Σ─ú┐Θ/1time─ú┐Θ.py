import  time
# 获取时间戳, 是从1970年1月1日0时0分0秒距离现在经过的秒数
# print(time.time())   # 1672366080.232501

# 延迟执行 单位是秒
print(123)
time.sleep(5)  # 后面的程序,延迟5秒执行
print('hello')