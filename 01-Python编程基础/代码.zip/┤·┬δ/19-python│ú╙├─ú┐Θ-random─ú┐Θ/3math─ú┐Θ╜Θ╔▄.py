# math() 模块的应用
import math
# 1.向上取整  math.ceil()
num1 = 12.11
print(math.ceil(num1))  # 13

# 2.向下取整  math.floor()
num2 = 19.99
print(math.floor(num2))  # 19

# 3.开平方  math.sqrt()
num3 = 49
print(math.sqrt(num3))  # 7.0