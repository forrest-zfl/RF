# 1.求绝对值  abs()
print(abs(-11))   # 11

# 2.获取最大数 max()
max1 = max(87,435,79,53,82)
print(max1)  # 435

# 3.获取最小数 min()
min1 = min(87,435,79,53,82)
print(min1)  # 53

# 4.pow(n,m) 计算某个数的几次幂
print(pow(2,3))  # 8  表示计算2的3次幂

# 5.round() 表示四舍五入
print(round(56.542))  # 57






