name = '印度阿三'
age = 18

def say():
    print('老鼠爱大米')

def demo():
    print('天使的眼泪')

def register():
    print('注册的功能')

def login():
    print('登录的功能')