# 一维元组
tup1 = (12,3,67,86,True,False,65.734)
print(tup1[4])   # True

# 二维元组
tup2 = (43.54,67,4,54.8,(45,48,53,89),True,False,'hello')
print(tup2[4][1])   # 48

# 三维元组
tup3 =  (43.54,67,4,54.8,(45,48,('哈哈',99,'C罗',84),53,89),True,False,'hello')
print(tup3[4][2][2])   # C罗