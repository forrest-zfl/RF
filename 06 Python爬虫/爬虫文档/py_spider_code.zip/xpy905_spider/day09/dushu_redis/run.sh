#!/bin/bash
cd /usr/src
scrapy crawl guoxue