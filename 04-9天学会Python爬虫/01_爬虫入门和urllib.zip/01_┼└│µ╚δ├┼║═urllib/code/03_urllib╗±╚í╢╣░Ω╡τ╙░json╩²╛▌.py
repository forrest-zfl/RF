from urllib import request

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 豆瓣电影的网址
url = "https://movie.douban.com/j/new_search_subjects?sort=T&range=0,10&tags=&start=0"

# 开始爬
req = request.Request(url, headers=headers)
response = request.urlopen(req)

result = response.read().decode()
print(type(result))  # str
print(result)
# result是json数据: 字典或列表等

# json解析：将字符串=>字典
import json
d = json.loads(result)
print(type(d))
print(d)

# 从字典d中一层一层取你想要的数据
data_list = d['data']
for data in data_list:
    title1 = data['title']  # 电影名
    rate1 = data['rate']  # 评分
    print(title1, rate1)

    # 把数据存入csv文件
    with open('douban.csv', 'a', encoding='utf-8') as fp:
        fp.write(f'{title1}, {rate1}\n')


