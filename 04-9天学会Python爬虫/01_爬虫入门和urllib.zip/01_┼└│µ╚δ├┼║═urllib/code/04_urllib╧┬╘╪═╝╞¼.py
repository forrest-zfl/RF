from urllib import request

# 下载图片
request.urlretrieve(
    url='https://www.baidu.com/img/pc_79bff59263430e2e42693b50cf376490.png',
    filename='baidu.png'
)
# 清空缓存
request.urlcleanup()

