# urllib是Python自带的库，可以使用http协议

from urllib import request

# 请求头：模拟浏览器
headers = {
    # 用户代理： 包含用户所在的浏览器版本和操作系统版本
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 百度搜索网址
url = 'https://www.baidu.com/s?wd=python'

# 使用urllib发送请求，得到url的结果
# 创建Request请求对象
req = request.Request(url=url, headers=headers)
# 打开网页，爬取数据
response = request.urlopen(req)
# response就是我们要拿到数据(服务器给我们的响应数据)
print(response)  # HTTPResponse对象

# read(): 得到响应数据内容
result = response.read().decode()
# print(result)

# b"hello"  # 二进制数据
# 二进制： 图片，视频

# bytes.decode(): 解码：二进制=>字符串
# str.encode(): 编码：字符串=>二进制

# 将result字符串存入html文件中
with open('result.html', 'w', encoding='utf-8') as fp:
    fp.write(result)


