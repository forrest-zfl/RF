# 学习爬虫需要提前掌握的知识点
# Python语言
#   变量，数据类型，运算符，分支语句，循环语句，函数，类
# 常用包：
#   math, os, json
#   yield关键字，生成器函数 （爬虫框架会用）
#
#
import json
# json.loads()
# json.dumps()

# MySQL: 存数据
#   pymysql

# HTML标签
# CSS 样式
# JS 语言

