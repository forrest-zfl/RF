import requests
# 安装
# pip install requests -i https://pypi.douban.com/simple

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}
# http协议常用的2种请求方式： get，post
# get方式
response = requests.get(url='http://www.qq.com', headers=headers)
# print(response)  # <Response [200]>
# print(type(response))  # <class 'requests.models.Response'>
# print(response.text)  # 字符串内容：内部已经自动将二进制以utf-8的方式解码了
# print(response.content)  # 二进制内容: 图片，视频，文件等
# print(response.content.decode('utf-8'))
# print(response.json())  # json解析：不用自己导入json库
# 必须掌握：
#   response.text
#   response.content
#   response.json()
print(response.status_code)  # 状态码
# 200 表式成功
#  1xx: 接收了一部分数据
#  2xx: 表式成功, 常见的是：200
#  3xx: 表式重定向, 常见的是: 301,302
#  4xx: 表式客户端出错了，常见的是：404,403,400
#  5xx: 表式服务端出错了，常见的是：500,502

# requests爬取阿里招聘
url = 'https://job.alibaba.com/zhaopin/socialPositionList/doList.json'
response = requests.get(url, headers=headers)
result = response.json()  # json解析
# print(result)

# 遍历每一个job
for job in result['returnValue']['datas']:
    degree = job['degree']
    location = job['workLocation']
    name = job['name']
    print(name, location, degree)


# post方式
# requests.post()
# requests.request(method='post')



