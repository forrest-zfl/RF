import requests

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 虎牙直播的url
# 新的url: jsonp技术
# url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=2168&tagAll=0&callback=getLiveListJsonpCallback&page=1'
#
# # 爬取
# response = requests.get(url, headers=headers)
# result = response.text
# # print(result)
#
# import re
# jsonstr = re.findall('getLiveListJsonpCallback\((.*?)\)', result)[0]
# # print(jsonstr)
#
# import json
# d = json.loads(jsonstr)
# print(d)

# 旧的url
url = 'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId=2168&tagAll=0&page=1'

response = requests.get(url, headers=headers)
result = response.json()
# print(result)

# 自动创建一个文件夹
import os
if not os.path.exists('huya'):
    os.mkdir('huya')

# 遍历每一个主播
for zb in result['data']['datas']:
    nick = zb['nick']  # 名字
    screenshot = zb['screenshot']  # 图片url
    # print(nick, screenshot)

    # 下载图片
    from urllib import request
    request.urlretrieve(screenshot, f'huya/{nick}.jpg')
    request.urlcleanup()

