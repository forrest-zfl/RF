
# 阿里招聘网:
#     https://job.alibaba.com/zhaopin/socialPositionList/doList.json
#
# 提示: 打开网址获取JSON数据, 保存到文件csv中

from urllib import request

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}
url = 'https://job.alibaba.com/zhaopin/socialPositionList/doList.json'

# 开始爬
req = request.Request(url, headers=headers)
response = request.urlopen(req)
result = response.read().decode()
# print(result)

# JSON解析： 字符串 => 字典
import json
d = json.loads(result)
# print(d)

# 遍历每一个job
for job in d['returnValue']['datas']:
    # 学历
    degree = job['degree']
    # 工作地点
    location = job['workLocation']
    # 岗位名称
    name = job['name']

    # 存入csv
    with open('alijob.csv', 'a', encoding='utf-8') as fp:
        fp.write(f'{name}, {location}, {degree} \n')
