import scrapy.cmdline

scrapy.cmdline.execute('scrapy crawl mymeiju'.split())

# 不显示日志：
#  1.输出干净
#  2.就算错了也不会提示
# scrapy.cmdline.execute('scrapy crawl mymeiju --nolog'.split())

# 创建项目:
#     scrapy startproject meiju
# 创建爬虫文件:
#     scrapy genspider mymeiju meijutt.tv
# 运行项目：
#     scrapy crawl mymeiju

# -o  快速存储
# ('json', 'jsonlines', 'jl', 'csv', 'xml', 'marshal', 'pickle')
# scrapy.cmdline.execute('scrapy crawl mymeiju -o meiju.csv --nolog'.split())
# scrapy.cmdline.execute('scrapy crawl mymeiju -o meiju.json'.split())


