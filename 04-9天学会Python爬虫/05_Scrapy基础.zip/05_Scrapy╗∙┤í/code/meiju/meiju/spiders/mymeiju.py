import scrapy
from ..items import *

# 1.必须继承scrapy.Spider
# 2.不用自己创建对象，内部会自动创建对象
class MymeijuSpider(scrapy.Spider):
    # 爬虫名：唯一
    name = 'mymeiju'
    # 允许的域名
    allowed_domains = ['meijutt.tv']
    # 开始爬取的url列表
    start_urls = ['https://www.meijutt.tv/new100.html']

    # parse：
    #   1. 自动接收响应数据
    #   2. parse函数会被自动调用
    def parse(self, response, **kwargs):
        pass
        print('*' * 80)
        # print(response.text)  # 文本内容
        # print(response.body)  # 二进制内容
        # print(response.json())  # json解析
        print('*' * 80)

        # xpath
        # response集成了xpath
        li_list = response.xpath('//*[@class="top-list  fn-clear"]/li')
        for li in li_list:
            # 美剧名字
            # get(): 获取内容
            mj_name = li.xpath('./h5/a/text()').get()
            # 美剧类型
            mj_type = li.xpath('./*[@class="mjjq"]/text()').get()

            # print(mj_name, mj_type)

            # 一条条传入到piplines.py文件中
            #  1.必须在settings中配置ITEM_PIPELINES
            #  2.在爬虫文件中需要yield返回数据(item 或 dict)
            # yield {'mj_name': mj_name, 'mj_type': mj_type}
            # yield MeijuItem(name=mj_name, type=mj_type)
            item = MeijuItem()
            item['name'] = mj_name
            item['type'] = mj_type
            yield item

