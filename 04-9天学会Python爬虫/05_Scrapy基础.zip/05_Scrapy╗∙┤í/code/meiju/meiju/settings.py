BOT_NAME = 'meiju'
SPIDER_MODULES = ['meiju.spiders']
NEWSPIDER_MODULE = 'meiju.spiders'

# User-Agent
USER_AGENT = 'meiju (+http://www.yourdomain.com)'

# 是否遵守robots协议(爬虫协议)
# 服务器在根目录下有一个robots.txt文件
ROBOTSTXT_OBEY = False

# 同时请求的最大并发数,默认16
CONCURRENT_REQUESTS = 32
# 爬取的时间间隔，建议提供
DOWNLOAD_DELAY = 3

# 配置管道
ITEM_PIPELINES = {
   'meiju.pipelines.MeijuPipeline': 300,
}

