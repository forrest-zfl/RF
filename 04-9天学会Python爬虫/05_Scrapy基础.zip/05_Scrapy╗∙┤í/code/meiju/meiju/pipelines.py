import pymysql


class MeijuPipeline:

    # 存储Item:
    #   写多少个yield，这里就会调用多少次
    def process_item(self, item, spider):

        # print('item:', item)

        # 存储数据
        # csv
        # with open('mj.csv', 'a', encoding='utf-8') as fp:
        #     fp.write(f'{item["name"]}, {item["type"]}\n')

        # 存入MySQL

        with self.db.cursor() as cur:
            sql = f'insert into tb_meiju(name,type) ' \
                  f'value("{item["name"]}", "{item["type"]}")'
            cur.execute(sql)

        self.db.commit()
        print('插入成功!')

        return item

    # 开始爬取的时候会自动调用
    def open_spider(self, spider):
        print('开始爬取...')
        self.db = pymysql.connect(
            user='root', password='root',
            database='db7'
        )

    # 结束爬取的时候会自动调用
    def close_spider(self, spider):
        print('爬取结束!')
        self.db.close()

