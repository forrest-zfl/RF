
# 使用xpath解析html数据

# 爬取51job全部城市岗位，并分别保存到单独的以城市名为文件名的html中，如: 深圳.html
# url = "https://jobs.51job.com/"

import requests
import os
import time
from lxml import etree

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36',
    'Cookie': 'guid=b103a9cf7d39a7f7996d4c13e1a3f22f; nsearch=jobarea%3D%26%7C%26ord_field%3D%26%7C%26recentSearch0%3D%26%7C%26recentSearch1%3D%26%7C%26recentSearch2%3D%26%7C%26recentSearch3%3D%26%7C%26recentSearch4%3D%26%7C%26collapse_expansion%3D; _uab_collina=164568940898081970912694; search=jobarea%7E%60000000%7C%21ord_field%7E%600%7C%21recentSearch0%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FApython%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch1%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch2%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%CA%FD%BE%DD%B2%FA%C6%B7%BE%AD%C0%ED%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch3%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%CA%FD%BE%DD%B7%D6%CE%F6%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch4%7E%60260200%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22b103a9cf7d39a7f7996d4c13e1a3f22f%22%2C%22first_id%22%3A%2218216ae2dbb1dd-0e13ce465fa8598-26021a51-935424-18216ae2dbd530%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMTgyMTZhZTJkYmIxZGQtMGUxM2NlNDY1ZmE4NTk4LTI2MDIxYTUxLTkzNTQyNC0xODIxNmFlMmRiZDUzMCIsIiRpZGVudGl0eV9sb2dpbl9pZCI6ImIxMDNhOWNmN2QzOWE3Zjc5OTZkNGMxM2UxYTNmMjJmIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22b103a9cf7d39a7f7996d4c13e1a3f22f%22%7D%2C%22%24device_id%22%3A%2218216ae2dbb1dd-0e13ce465fa8598-26021a51-935424-18216ae2dbd530%22%7D; acw_tc=ac11000116663537959432331e00e0317d29c6771f3a469f49c68bbc64bdbe; acw_sc__v2=63528a834c179732b152a7dc6d4f34d06ecaad09; ssxmod_itna=CqGxgD2DcDuDnD0ODlRhIYG=kFkQ7iiQ0R70DBkO4iNDnD8x7YDvIGwYIDmh7HhGeWDNh754KAKmx+3etQGRWbflIDB3DEx0=KMfQxiinDCeDIDWeDiDG4ODXZK0OD7qiOD7r=DLDW51DFqG09b=eD0PKtmG9D73DUddDQqDS8nPxxGQMDitcDGYMD0UjD7QMCjNDewptsqGW8wDD0wDkoiK4/e6HsaNYvnbQynuQgQdrMlaWGkUMWqGm9fnqkLgSjMazCDp1C7419x+oWipiG0D5YGhQ/FeKY7wQzSM1bVE4G010gvDDG4xeB4sxx4D; ssxmod_itna2=CqGxgD2DcDuDnD0ODlRhIYG=kFkQ7iiQ0R7D8Mn7PGNDO/DF2O=Ig9ha2oKAPz=jCBR5rrj7iA7jGiiBuDuQjCSqhRP4a9dquxXKBLMYFYBcwxTHpaBqBWY/bkIaHnQhW93uCks+AqF93=PKDxZSgoPimAlzf5+/RX7RMj9QAts+uP5pwo4eRv9Ro6s+gLuS4uAbl6RlMoQP2fUFmaeQRFL/whHY4bzRoUz+SfHy=IP6kjCjdUCiYQYkuPQTpEqxm9m2jngFlygDZrPrjlv0fy5o8fss8fbweEpRwYjD66MI413vN270mMtpgSvZD7A/Hz3cs0ybDHQWbzR5XlyT/b8WRqTAzWRHBHziuD3Kr7iKQF+Q7Y7r+FyQFgalmdtW+IYNI436bwzgOFGWFEd+vlDFrS4Y5rrbu=NSn+hdRr+KIdWR=p9IFW+GaRFgRSHNRHk/R1lSvFgObqYwHQUEytAEUqYNwthnb0mksyNyT1pIi27kggD5LbfdLmkW+B3=QGTjrVBdkuhOoekLK9uatxDKkeKdosboD=Q8KWhAu=pxGKHD7=DYKxeD'
}

# 获取所有城市
def get_citys(url):
    # 获取网页数据
    response = requests.get(url, headers=headers)
    content = response.content.decode('gbk')
    # print(content)

    # xpath解析
    mytree = etree.HTML(content)
    a_list = mytree.xpath('//*[@class="e e4"][1]/*[@class="lkst"][1]/a')
    # print(a_list)
    for a in a_list:
        name = a.xpath('./text()')[0]  # 城市名
        href = a.xpath('./@href')[0]  # 链接

        get_job(href, name)
        time.sleep(3)


# 获取每个城市的岗位信息
def get_job(url, name):
    # 获取网页数据
    response = requests.get(url, headers=headers)
    content = response.content.decode('gbk')
    # print(content)

    # xpath解析
    #  取岗位名称，岗位城市，岗位薪资，学历
    mytree = etree.HTML(content)
    div_list = mytree.xpath('//*[@class="detlist gbox"]/div')
    for div in div_list:
        # 岗位名称
        name = div.xpath('.//*[@class="title"]/a/text()')
        # 城市
        city = div.xpath('.//*[@class="location name"]/text()')
        # 薪资
        salary = div.xpath('.//*[@class="location"]/text()')
        # 学历
        degree = div.xpath('.//*[@class="order"]/text()')

        print(name, city, salary, degree)


if __name__ == '__main__':
    url = "https://jobs.51job.com/"
    get_citys(url)



