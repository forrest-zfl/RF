import requests

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 代理IP
# 芝麻代理  https://jahttp.zhimaruanjian.com/
# 110.18.2.31:4234
# 115.239.16.142:4214
# 125.79.0.94:4235
# 122.241.221.13:4231

# 1. 获取代理IP
def get_ip():
    # 从芝麻代理服务器自动获取代理IP
    url = 'http://webapi.http.zhimacangku.com/getip?num=3&type=1&pro=0&city=0&yys=0&port=1&pack=37767&ts=0&ys=0&cs=0&lb=1&sb=0&pb=4&mr=1&regions='
    response = requests.get(url)
    result = response.text

    # 代理IP的列表
    proxy_list = []
    for ip in result.splitlines():
        proxy_list.append({'http': ip})
    return proxy_list

# 2. 使用代理IP
import random
def get_data(proxy_list):
    # 随机选取一个代理IP
    proxy = random.choice(proxy_list)
    print(f'正在使用的proxy: {proxy["http"]}')

    # 开始爬虫
    try:
        response = requests.get(
            url='http://www.ifeng.com',
            headers=headers,
            proxies=proxy,  # 设置代理IP
            timeout=5  # 超时时间，请求超时后会自动报错
        )
        print('爬取成功:', len(response.text))

    except Exception as e:
        print('爬取失败:', e)
        # 如果爬取失败，则说明代理IP已失效(被反爬或IP无效)
        proxy_list.remove(proxy)

        # 如果IP已经用完，继续从芝麻代理服务器获取
        if len(proxy_list) == 0:
            proxy_list = get_ip()

        # 继续调用get_data,重新爬取
        print('更换新的代理IP后，继续爬取...')
        get_data(proxy_list)


if __name__ == '__main__':
    proxy_list = get_ip()
    print(proxy_list)
    # [ {'http': '183.7.125.120:4215'},
    #   {'http': '119.249.40.165:4231'},
    #   {'http': '113.141.222.17:4224'}
    # ]

    get_data(proxy_list)






