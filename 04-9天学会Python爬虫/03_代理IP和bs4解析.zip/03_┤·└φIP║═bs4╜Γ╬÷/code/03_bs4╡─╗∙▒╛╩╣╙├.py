
# 先安装bs4,lxml
# pip install beautifulsoup4
# pip install lxml

# 导入bs4
from bs4 import BeautifulSoup

html_doc = '''
<html>
    <head>
        <title>The Dormouse's story</title>
    </head>
    <body>
        <p class="title">
            <b>The Dormouse's story</b>
        </p>
        <p class="story">
            <a class="sister" href="http://elsie" id="link1">Elsie</a>
            <a class="sister" href="http://lacie" id="link2">Lacie</a>
            <a class="sister" href="http://tillie" id="link2">Tillie</a>
        </p>
        <p class="story">
            <a class="boy" href="http://libai" id="link1">李白</a>
        </p>
    </body>
</html>
'''

# 创建bs4对象
soup = BeautifulSoup(html_doc, 'lxml')
# print(soup, type(soup))

# 取html中的属性值或内容
#  都要先取标签

# 标签tag
# print(soup.head)
# print(soup.title)
# print(soup.p)  # 第一个p标签

# 属性
# print(soup.p.attrs)  # 得到p的所有属性
# print(soup.a.attrs['href'])
print(soup.a['href'])

# 内容
print(soup.a.text)

# find_all() : 找到所有匹配的标签，会返回一个列表
# print(soup.find_all('a'))
# print(soup.find_all('a', id='link1'))
# print(soup.find_all(['b', 'title']))

# css选择器（推荐使用）
print(soup.select('.boy'))  # class="boy"
print(soup.select('.title'))  # class="title"
print(soup.select('#link1'))  # id="link1"
print('-' * 80)

sister_list = soup.select('.sister')
for sister in sister_list:
    print(sister.text)  # 内容
    print(sister['href'])  # 属性值

# 层级选择器
print(soup.select('p .boy'))