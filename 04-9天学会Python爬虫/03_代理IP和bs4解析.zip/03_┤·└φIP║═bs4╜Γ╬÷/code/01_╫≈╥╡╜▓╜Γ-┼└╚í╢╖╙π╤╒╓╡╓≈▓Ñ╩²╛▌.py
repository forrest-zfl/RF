
# 斗鱼颜值主播网页地址: https://www.douyu.com/g_yz

# 通过上面的网址可以抓到下面的斗鱼美女数据接口：
# https://www.douyu.com/wgapi/ordnc/live/web/room/yzList/2


import requests
from urllib import request

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 翻页
def douyu(page=1):
    url = f'https://www.douyu.com/wgapi/ordnc/live/web/room/yzList/{page}'

    # 开始爬取
    response = requests.get(url=url, headers=headers)
    result = response.json()

    for zb in result['data']['rl']:
        name = zb['nn']
        img = zb['rs16']
        # print(page, name, img)

        # 下载图片
        request.urlretrieve(img, f'douyu/{name}.png')

import time
import os
if __name__ == '__main__':
    if not os.path.exists('douyu'):
        os.mkdir('douyu')

    # 爬取1-6页
    for i in range(1, 7):
        douyu(i)
        time.sleep(1)




