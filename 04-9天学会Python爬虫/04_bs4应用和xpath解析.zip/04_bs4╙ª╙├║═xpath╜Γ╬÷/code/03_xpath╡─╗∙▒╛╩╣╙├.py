# 解析html
# 1.xpath
# 2.bs4 : css选择器
# 3.re正则

# xpath的基本使用
# 安装lxml
#    pip install lxml
from lxml import etree

html_doc = '''
<html>
    <head>
        <title>The Dormouse's story</title>
    </head>
    <body>
        <p class="title">
            <b>The Dormouse's story</b>
        </p>
        <p class="story">
            <a class="sister" href="http://elsie" id="link1">Elsie</a>
            <a class="sister" href="http://lacie" id="link2">Lacie</a>
            <a class="sister" href="http://tillie" id="link2">Tillie</a>
        </p>
        <p class="story">
            <a class="boy" href="http://libai" id="link1">李白</a>
        </p>
    </body>
</html>
'''

# xpath
# 创建xpath对象
mytree = etree.HTML(html_doc)
# print(mytree)  # <Element html>

# 子节点： /
# 后代节点: //
# print(mytree.xpath('/html'))
# print(mytree.xpath('/html/head'))
# print(mytree.xpath('//head'))
# print(mytree.xpath('//a'))  # 默认找到所有的a标签
# print(mytree.xpath('//a')[0])  # 第一个a标签
# print(mytree.xpath('//a[1]'))  # 每个p标签下的第一个a标签
# print(mytree.xpath('//p[2]/a[1]'))

# 属性: @
# print(mytree.xpath('//a/@href'))
# print(mytree.xpath('//p/@class'))

# 文本内容: text()
# print(mytree.xpath('//a/text()'))
# print(mytree.xpath('//b/text()'))

# 谓词：条件
# 按条件查找对应的标签
# print(mytree.xpath('//p[2]/a[1]'))  # 第1个
# print(mytree.xpath('//p[2]/a[last()]'))  # 最后1个
# print(mytree.xpath('//p[2]/a[last()-1]'))  # 倒数第2个

# 找到属性id=“link1”的a标签
# print(mytree.xpath('//a[@id="link1"]'))
# print(mytree.xpath('//a[@class="boy"]'))

# 通配符 *
# 不在乎标签名是什么，只需要满足class="boy"即可
# print(mytree.xpath('//*[@class="boy"]'))

# 下面的功能使用较少
# 或 |
# print(mytree.xpath('//*[@class="boy"] | //b'))

# 包含： contains()
# print(mytree.xpath('//a[contains(text(),"ci")]/text()'))
# print(mytree.xpath('//a[contains(@href,"ci")]/text()'))

# 练习：查找第二个p标签中的每个a标签的内容和href属性值
a_list = mytree.xpath('//p[2]/a')
for a in a_list:
    name = a.xpath('./text()')[0]
    href = a.xpath('./@href')[0]
    print(name, href)

# 注意： xpath返回的一个列表


