import requests
from lxml import etree

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 股票基金网址
url = 'http://quote.stockstar.com/fund/stock.html'

# 使用xpath解析
# 1.requests爬取数据
response = requests.get(url, headers=headers)
result = response.content.decode('gbk')

# 2.xpath解析html
mytree = etree.HTML(result)
li_list = mytree.xpath('//ul[@id="index_data_0"]/li')
for li in li_list:
    code = li.xpath('./span/a/text()')[0]
    name = li.xpath('./a/text()')[0]
    print(name, code)

    # 3.存入csv(存储：名称和市值)
    with open('stock.csv', 'a', encoding='utf-8') as fp:
        fp.write(f'{code}, {name}\n')
