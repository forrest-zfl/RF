
# 使用bs4解析html数据

# 爬取51job全部城市岗位，并分别保存到单独的以城市名为文件名的html中，如: 深圳.html
# url = "https://jobs.51job.com/"

import requests
import os
from bs4 import BeautifulSoup
import time

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36',
    'Cookie': 'guid=b103a9cf7d39a7f7996d4c13e1a3f22f; nsearch=jobarea%3D%26%7C%26ord_field%3D%26%7C%26recentSearch0%3D%26%7C%26recentSearch1%3D%26%7C%26recentSearch2%3D%26%7C%26recentSearch3%3D%26%7C%26recentSearch4%3D%26%7C%26collapse_expansion%3D; _uab_collina=164568940898081970912694; search=jobarea%7E%60000000%7C%21ord_field%7E%600%7C%21recentSearch0%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FApython%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch1%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch2%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%CA%FD%BE%DD%B2%FA%C6%B7%BE%AD%C0%ED%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch3%7E%60000000%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%CA%FD%BE%DD%B7%D6%CE%F6%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21recentSearch4%7E%60260200%A1%FB%A1%FA000000%A1%FB%A1%FA0000%A1%FB%A1%FA00%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA99%A1%FB%A1%FA9%A1%FB%A1%FA99%A1%FB%A1%FA%A1%FB%A1%FA0%A1%FB%A1%FA%A1%FB%A1%FA2%A1%FB%A1%FA1%7C%21; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22b103a9cf7d39a7f7996d4c13e1a3f22f%22%2C%22first_id%22%3A%2218216ae2dbb1dd-0e13ce465fa8598-26021a51-935424-18216ae2dbd530%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMTgyMTZhZTJkYmIxZGQtMGUxM2NlNDY1ZmE4NTk4LTI2MDIxYTUxLTkzNTQyNC0xODIxNmFlMmRiZDUzMCIsIiRpZGVudGl0eV9sb2dpbl9pZCI6ImIxMDNhOWNmN2QzOWE3Zjc5OTZkNGMxM2UxYTNmMjJmIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22b103a9cf7d39a7f7996d4c13e1a3f22f%22%7D%2C%22%24device_id%22%3A%2218216ae2dbb1dd-0e13ce465fa8598-26021a51-935424-18216ae2dbd530%22%7D; acw_tc=ac11000116661846225876716e00e0143e185a70fc9f3341d96b03948b85ef; acw_sc__v2=634ff5ae59f3836928ba1f73f59785c63e83119b; ssxmod_itna=iq0x9DyQGQqmu4BcDeTm8RWRYOCDcYxQqhuPDsWGrDSxGKidDqxBWWCxDQrdSdGnrDxfGwUi2hxWYQiDcwrAQQb3YIrt4B3DEx06rbKexiicDCeDIDWeDiDGRODXo50OD7qiOD7E=DLDAUMD7=D4uL9ADDHKrr1GqGEDBtUD0QDAqRH3eDRRqDg8qD+RqDMB4G2RdbDxijFDatDbxt1DDN1RavOnrncma9/InRQynuiglTU3PWOrOtMnL=DbRdWaetA2dNOMODW8Y4zFGGYU++r90hxnOeqKw4ncoqqA7G2F71MriYBXiC2xDAAGtjDleD==; ssxmod_itna2=iq0x9DyQGQqmu4BcDeTm8RWRYOCDcYxQqhqikvWqqDl2Q4jR42bQK+2RbLrQideU2w+js7+hAPPD0Dm4p7GFSlBGmdxZl3hpKEAP8LwKQ4b7TIYKcREuU5X1wOkgT1K1ybg3Vgw+q274NUPwdVjD4DPBhMjYFYfBNxbxNYFPptQFrDE7pwomsb=FGx=uhpfAxwoE+ZEcN8EgNHPdmrZwQ+hYiH=PXntyIZKufg9EGwgumouQu0Pf+uFfN0cei/n5W7dCC2xH6RDvr9QL=l8lgrE=i9DygpNCC=oVScZZ0tOQUrcaar=dCOq9=NLZejlNjjGcPwrlhSBmEjhgmjPeKkjfe1wLj35zqhjfxG53r5FQql0IPeArepeGDLPPvn5hlKbPqvQdoowPjN7PYLguO0Iw7eH6owm=i26NO3r1ApoL2WLLQL8OnGZwLzt6Qt+ccGP09cju1P4KNGgtga9ScQw0p2Ct1c5Bcj0PwOg993FwrUI6Q2=K7x7rhXj39OxLn9n/EjqIuq8GTDG29i=82Y0qTn4=iqxjQdvuIZlCAuc30EU4K72DWR9t1qURtD08DiQIYD=='
}

# 获取所有城市
def get_citys(url):
    # 获取网页数据
    response = requests.get(url, headers=headers)
    content = response.content.decode('gbk')
    # print(content)

    # bs4解析
    soup = BeautifulSoup(content, 'lxml')
    a_list = soup.select('.lkst')[0].select('a')
    for a in a_list:
        name = a.text  # 城市名
        href = a['href']  # 城市链接
        # 获取每个城市的岗位信息
        get_job(href, name)
        time.sleep(2)


# 获取每个城市的岗位信息
def get_job(url, name):
    # 获取网页数据
    response = requests.get(url, headers=headers)
    content = response.content.decode('gbk')
    # print(content)

    # bs4解析
    soup = BeautifulSoup(content, 'lxml')
    div_list = soup.select('.detlist div')
    for div in div_list:
        title = div.select('.title a')[0].text
        print(f'{name}: {title}')


if __name__ == '__main__':
    url = "https://jobs.51job.com/"
    get_citys(url)


