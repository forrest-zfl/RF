
# http://quote.stockstar.com/fund/stock.html
# 爬取企业代码和企业名称

import requests
from bs4 import BeautifulSoup

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
}

# 股票网站
url = 'http://quote.stockstar.com/fund/stock.html'

# 开始爬
response = requests.get(url, headers=headers)
# result = response.text  # 默认会使用utf-8解码
result = response.content.decode('gbk')  # 股票网站内部是gb2312
# print(result)

# bs4解析
soup = BeautifulSoup(result, 'lxml')
# 方式1： find_all()
'''
ul = soup.find_all('ul', id="index_data_0")[0]
li_list = ul.find_all('li')
for li in li_list:
    code = li.find_all('a')[0].text
    name = li.find_all('a')[1].text
    print(name, code)
'''

# 存储数据
#  1.txt文件
#  2.csv文件
#  3.mysql
#    ①先创建数据库和表
#    ②然后在插入数据
import pymysql
# 1.连接MySQL
db = pymysql.connect(
    user='root', password='root',
    host='localhost', port=3306,
    database='db7'
)
cursor = db.cursor()

# 方式2： select()
li_list = soup.select('#index_data_0 li')
for li in li_list:
    code = li.select('a')[0].text
    name = li.select('a')[1].text
    print(name, code)

    # 2.插入数据
    sql = f'insert into tb_stock(code, name) value("{code}", "{name}")'
    cursor.execute(sql)

db.commit()

# 3.关闭链接
cursor.close()
db.close()




